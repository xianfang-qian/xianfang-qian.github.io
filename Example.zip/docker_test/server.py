"""
Copyright 2021 Intel Corporation

This software and the related documents are Intel copyrighted materials,
and your use of them is governed by the express license under which they
were provided to you ("License"). Unless the License provides otherwise,
you may not use, modify, copy, publish, distribute, disclose or transmit
this software or the related documents without Intel's prior written permission.

This software and the related documents are provided as is, with no express or
implied warranties, other than those that are expressly stated in the License
"""

import os
import math
import sys
import time
import json
import influxdb
import logging
from argparse import ArgumentParser
import multiprocessing as mp
from flask import Flask, Response, jsonify, render_template, make_response
import requests
from threading import Thread, Lock
from importlib import import_module

# import camera driver
if os.environ.get('CAMERA'):
    Camera = import_module('camera_' + os.environ['CAMERA']).Camera
else:
    from camera import Camera



app = Flask(__name__)
log = logging.getLogger(__name__)

SERVER_HOST = os.getenv('LOCAL_HOST')
NAMESPACE = os.getenv('NAMESPACE')
INFLUXDB_HOST = "influxdb.{}.svc".format(NAMESPACE)
INFLUXDB_PORT = "8086"

#DATABASE_NAME = "HelloWorld"
DATABASE_NAME = "McssCovid"
NETWORK_FPS = 20
NUM_CH = 1
RUNNING = []
MUTEX = None
CONFIG_PATH = None
CONF_DATA, URL_DATA = {}, {}
Q_DATA = {}
CURRENT_FRAMES = []
FPS = []



#@app.route('/get_all_streams')
#def get_all_streams("Text"):
#   """
#    Route to show all running video streams
#    """
#    return "HelloWorld,Please try again!"


print("Start to connect to influxdb...")
try:
    client = influxdb.InfluxDBClient(host=INFLUXDB_HOST, port=INFLUXDB_PORT,
                                        username="admin",
                                        password="admin",
                                        database=DATABASE_NAME)

    client.create_database(DATABASE_NAME)
    print("Connect sucess...")
except Exception:
    print("Connect failed...")
    sys.exit(-1)


@app.route("/")
def index():
    return "HelloWorld, Nice to see you!"

def gen(camera):
    """Video streaming generator function."""
    yield b'--frame\r\n'
    while True:
        frame = camera.get_frame()
        yield b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n--frame\r\n'


@app.route('/video_feed')
def video_feed():
    """Video streaming route. Put this in the src attribute of an img tag."""
    return Response(gen(Camera()),
                    mimetype='multipart/x-mixed-replace; boundary=frame')



mutex = Lock()


def add_data_to_influxdb(var1,var2):
    mutex.acquire()
    json_body = []
    #fields={var1:var2}
    json_body.append({"measurement": "OutPut",
                      #"tags": {"test":"helloword"},
                      "fields": {
                          "Test":var2}})

    print ("Start update InfluxDB.....:",var1)
#    client.write_points(content)
    client.write_points(json_body)
    time.sleep(5)
    print ("Update finished.....:",var1)
    time.sleep(0.5)
    mutex.release()


def main():
    print("Hello")
    n=1
    while n<=50:
        add_data_to_influxdb(n,n*0.01)
        print(n)
        time.sleep(2)
        n=n + 1
        print("hello world....:",n)
    app.run(host=SERVER_HOST, port=8000, threaded=True)


    try:
        print("Data Value from OutPut:")
        result = client.query('select * from OutPut;') 
        print("Result: {}".format(result))
    except Exception:
        pass

if __name__=='__main__':
        main()
