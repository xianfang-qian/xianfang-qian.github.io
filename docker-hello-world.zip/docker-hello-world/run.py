#!/usr/bin/env python
import time 
n = 1 
while n <= 10:
	print("hello world ",n)
	time.sleep(10)
	n = n + 1


